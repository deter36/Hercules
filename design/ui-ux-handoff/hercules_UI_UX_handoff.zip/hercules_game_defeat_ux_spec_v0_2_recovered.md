# Hercules Digital Adaptation — Game Defeat UX Spec v0.2 — RECOVERED

**Recovery status:** Reconstructed from preserved project context, Engine Execution Spec, Full Labor Resolution UX, and later implementation handoff.  
**Not guaranteed byte-for-byte identical to the lost original.**

## 1. Entry principle

**LOCKED**

The defeat flow begins only when the engine reports an explicit defeat condition.

The UI does not infer defeat from apparent impossibility or lack of useful placements.

Known defeat causes include:
- Spirit reaches failure / 0
- Labor die reaches a Skull/failure node
- current provisional Hind rule: final usable Hercules die breaks
- final Cerberus / endgame Divinity failure where applicable

## 2. Shared defeat language

**LOCKED**

All defeat causes converge on one restrained shared ending:

1. cause-specific cue completes
2. brief stillness
3. scene drains toward grayscale/desaturation
4. title appears: `YOUR JOURNEY IS OVER`
5. supporting line: `You have failed.`

Avoid overlong explanatory text during the emotional beat.

## 3. Cause-specific cues

### Skull

**LOCKED DIRECTION**
- Labor die completes movement onto Skull
- Skull receives strong emphasis
- board holds long enough for cause to be understood
- shared defeat transition begins

### Spirit 0

**LOCKED DIRECTION**
- Spirit tracker visibly resolves to failure/0
- tracker receives a restrained failure emphasis
- shared defeat transition begins

### Ceryneian Hind provisional failure

**LOCKED DIRECTION**
- final usable Hercules die receives the break treatment
- player sees that no usable die remains
- shared defeat transition begins

Do not trigger this when one usable Hercules die still remains.

### Final Divinity failure

**LOCKED DIRECTION**
- final required Divinity check/result is shown first
- failed state is visually clear
- shared defeat transition begins

## 4. Preserve causality

**LOCKED**

Do not obscure the board/resource state before the player can understand why defeat occurred.

The cause cue precedes the grayscale/title beat.

## 5. Controls after defeat

**PROVISIONAL**

Post-defeat controls may later include:
- Retry / New Game
- Review Run
- Main Menu

These controls appear after the core defeat beat, not during it.

Exact control set and navigation destination remain implementation/product decisions.

## 6. Presentation speed

Normal/Fast/Instant presentation settings may shorten transitions, but must not skip the minimum causal cue necessary to show why defeat occurred.

## 7. UI / Engine boundary

### Engine owns
- defeat condition
- defeat timing
- defeat cause identifier
- final canonical state

### UI owns
- cause cue presentation
- stillness/desaturation
- defeat typography
- post-defeat navigation controls

## Recovered locked summary

- explicit engine defeat only
- cause cue first
- brief stillness
- grayscale/desaturation
- `YOUR JOURNEY IS OVER`
- `You have failed.`
- specific treatment for Skull, Spirit 0, Hind final-die break, final Divinity failure
- no speculative defeat from apparent soft-lock
