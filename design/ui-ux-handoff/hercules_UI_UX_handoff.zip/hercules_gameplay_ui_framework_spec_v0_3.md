# Hercules Digital Adaptation — Gameplay UI Framework Spec v0.3

**Status:** Working UI authority  
**Scope:** Portrait mobile gameplay-page framework, persistent information, action-grid structure, tile behavior, phase behavior, player-input patterns, Labor-view transition, and UI/engine boundary.

This specification governs presentation and interaction only. It does **not** modify game rules or engine semantics. The deterministic engine remains authoritative for canonical state, legal actions, phase progression, dice state, Labor state, pending decisions, forecast results, and resolution.

---

## 1. Gameplay Screen Structure

**Status: LOCKED**

The gameplay screen uses four primary vertical regions:

1. Status Strip
2. Forecast Strip
3. Action Grid
4. Dice Tray + CTA Rail

Reference portrait viewport: approximately **390 × 844 px**.

Working allocation:
- Status Strip: ~50–60 px
- Forecast Strip: ~30–40 px
- Action Grid: all remaining central space
- Dice Tray + CTA Rail: ~140–160 px

Exact pixel dimensions remain provisional. The overall hierarchy is locked.

---

## 2. Status Strip

**Status: LOCKED**

Persistent information:
- Spirit
- Divinity
- current Labor number/name
- Mood/status indicator
- Menu control
- access to secondary status/detail information if needed

Behavior:
- always visible on gameplay screen
- icon-first presentation
- avoid verbose labels once tutorialization is complete
- Labor identification belongs here rather than inside the compact Labor tile
- Mood/status may expose details on tap
- Menu is fixed at the top-right
- Mood/status occupies the position immediately left of Menu

**Provisional:**
- exact icon treatment
- alignment
- settings/menu placement

---

## 3. Forecast Strip

**Status: LOCKED**

The Forecast is a single compact row.

It displays the deterministic consequences of resolving the **current valid committed assignment state**.

Example:
`♥ -3   🔥 -1   🎲✕ 1   Heal +1`

Rules:
- no expanded forecast panel
- no strategic recommendations
- only relevant projected effect categories appear
- use the same icon language as cards/abilities where practical
- zero-value entries may disappear
- loose selected dice do not affect Forecast
- valid-but-not-yet-placed attack candidates do not affect Forecast
- valid committed placements update Forecast immediately
- rejected/illegal placement attempts do not affect Forecast

The UI renders an engine-provided projection; it does not calculate consequences itself.

**Provisional:**
- neutral/no-effect presentation

---

## 4. Action Grid

**Status: LOCKED**

The central Action Grid contains:
- current Labor tile
- Bow tile
- owned Reward tiles
- temporary actionable tiles created by verified effects when applicable

There is **no permanent Mood tile**. A Mood/effect receives a tile only if it creates an actual player-facing action/placement target.

The grid must support sparse through dense states without changing the fixed top/bottom framework.

### Layout philosophy

**Status: LOCKED**

Use reusable tile components with flexible grid templates rather than twelve separately coded screens.

However:
- the Labor tile may use special sizing
- sparse and dense states may use different grid templates/manifests
- some Labor states may use hand-tuned layout manifests if needed
- layout should remain deterministic from game state/content

**Provisional:**
- exact grid templates
- exact tile aspect ratios
- minimum tile dimensions
- empty-slot collapse behavior

---

## 5. Compact Labor Tile

**Status: LOCKED AT FRAMEWORK LEVEL**

The Labor tile is the primary attack-assignment surface.

The compact tile does **not** display the Labor name; the current Labor is already identified in the Status Strip.

Minimum compact content per Labor target pane:
- current / starting health as `X/Y`
- active attack requirement iconography
- next-node effect iconography

No explanatory labels such as:
- Health
- Attack
- Drop attack dice here
- Next

### Target-pane structure

**Status: LOCKED**

Use one vertical pane per independently damageable Labor die:
- 1 Labor die → 1 full-width pane
- 2 Labor dice → 2 vertical panes
- 3 Labor dice → 3 vertical panes
- 4 Labor dice → 4 vertical panes

For shared Labor-wide attack requirements, show the requirement once when practical.

For per-target requirements, show the relevant requirement within each pane.

Defeated/inactive panes remain spatially present but are visually retired/inactive.

The exact in-pane treatment of assigned attack bundles is governed by the separate **Attack Assignment Interaction Spec**.

---

## 6. Ability Tiles

**Status: LOCKED**

Bow, Rewards, and temporary actionable effects use a common tile family.

Primary visual content:
- faint/muted artwork derived from the corresponding physical card
- blue and/or gold ability square(s)
- original card-game iconography where practical

Persistent Reward names are not required inside the tile if artwork provides sufficient identification.

Names/details may appear through:
- inspect/tap/hold
- tutorial overlays
- accessibility labels

### Phase behavior

**Status: LOCKED**

Inactive ability classes dim while preserving tile identity.

Blue phase:
- Blue spaces active
- Gold spaces dim
- Labor attack target inactive

Gold + Attack phase:
- Blue spaces dim
- Gold spaces active
- Labor attack target active

---

## 7. Blue Phase

**Status: LOCKED**

During Blue:
- legal Blue ability targets may highlight
- Gold targets are inactive
- Labor attack targets are inactive
- Hercules dice may be dragged or tap-selected onto legal Blue abilities

### Blue die parking

**Status: LOCKED WITH ENGINE GUARDRAIL**

Dice placed on Blue abilities remain visibly parked on the tile through the Blue phase.

If a Blue effect changes a die face, the visible die updates immediately.

On `Finish Blue`:
- reusable blue-used dice animate back to the tray with modified values intact
- dice actually spent/removed by the verified effect do not return

Presentation must preserve the engine distinction:
`blue_used != spent/locked`.

---

## 8. Gold + Attack Phase

**Status: LOCKED**

After Blue ends:
- Blue spaces dim
- Gold spaces activate
- Labor attack panes activate
- eligible dice may be assigned to Gold abilities or Labor attacks

Placed dice remain visible on their destinations.

Individual placement does **not** finalize the phase.

The explicit phase-completion action remains:
`RESOLVE_ASSIGNMENTS`

---

## 9. Dice Tray + CTA Rail

**Status: LOCKED**

The bottom region is a three-part horizontal control bar:

```text
┌──────┬──────────────────────┬──────┐
│ Undo │      Dice Tray       │ CTA  │
│      │                      │      │
└──────┴──────────────────────┴──────┘
```

- Undo occupies a compact fixed bottom-left control
- Dice Tray occupies the center
- Phase CTA occupies the fixed right rail

The CTA remains approximately 17–20% of screen width as a working target. Exact Undo width is provisional and must be validated against the 11-die tray.

### CTA states

**Status: LOCKED PRINCIPLE**

No loose dice selected:
- Ready to Roll → Roll action
- Blue phase → Finish Blue
- Gold + Attack → Resolve Assignments

Loose dice selected:
- CTA temporarily becomes **Unselect**

The exact iconography is provisional.

---

## 10. Dice Tray Density

**Status: PROVISIONAL BUT DIRECTIONALLY LOCKED**

The tray must support the full legal Hercules-dice range without opening a separate dice screen.

Working behavior:
- lower die counts: one row
- higher die counts: two rows
- 11 dice remain legible and comfortably selectable
- avoid shrinking dice excessively just to preserve one row

Assigned/parked dice leave the tray visually and appear on their current target.

---

## 11. Dice Selection and Placement

**Status: LOCKED AT FRAMEWORK LEVEL**

Primary input:
- drag-and-drop with snap-to-target

Secondary input:
- tap-select / tap-target

When one or more loose dice are selected:
- selected dice are visually highlighted
- dragging one selected die moves the whole selection
- legal targets returned by the engine highlight in the Action Grid
- legality is communicated by target highlighting, not by “valid/invalid” styling in the tray
- tapping empty background does not clear selection
- CTA becomes Unselect

Detailed attack-bundle construction, rejection/snapback behavior, and one-selection-one-attack rules are defined in the separate **Attack Assignment Interaction Spec v0.1**.

---

## 12. Legal-Target Highlighting

**Status: LOCKED**

Target highlighting applies across the full Action Grid, not only Labor attacks.

Depending on phase and engine-provided legality, highlighted targets may include:
- Blue ability squares
- Gold ability squares
- Labor target panes
- temporary actionable effect tiles

The UI does not independently calculate legality.

---

## 13. Invalid Placement Feedback

**Status: LOCKED PRINCIPLE**

Illegal drops do not commit canonical placement.

Preferred feedback:
- attempted placement rejects cleanly
- dice animate back to the tray or prior legal location
- relevant target gives a brief rejection response
- no modal by default

Detailed attack snapback behavior is defined in the Attack Assignment Interaction Spec.

---

## 14. Repositioning Before Resolution

**Status: LOCKED**

Before resolution, legal deterministic placements remain editable.

The player must be able to:
- remove a placement
- return dice/bundles to tray
- move legal assignments to another valid target where allowed

No confirmation is required merely for rearranging pre-resolution placements.

---

## 15. Resolve Assignments

**Status: LOCKED**

`Resolve Assignments` submits the current valid assignment state to the engine.

The GUI does not determine whether unused legal opportunities remain meaningful.

If the engine returns a resolve-anyway checkpoint, the UI shows a compact confirmation surface.

This warning is separate from illegal placement rejection.

---

## 16. Full Labor View

**Status: LOCKED CONCEPT**

The full Labor screen uses high-quality scans/images of the tabletop Labor cards rather than digitally recreating the card artwork.

Presentation overlays:
- physical gold Labor dice
- current track positions
- track-node hit regions
- branch highlights
- movement paths
- impact/effect animation

Each Labor receives a visual layout manifest defining:
- source image(s)
- card positions
- normalized node coordinates
- Labor die size
- branch hit areas
- multi-card arrangement

The engine's track graph remains authoritative. Image mapping is presentation only.

---

## 17. Access to Full Labor View

**Status: PROVISIONAL**

Preferred model:
- right-edge tab/handle
- tap to open
- optional edge-origin swipe

Avoid swipe-anywhere because it may conflict with dice dragging.

---

## 18. Resolution Transition

**Status: LOCKED CONCEPT**

When assignments resolve:

`Gameplay Screen → Full Labor View`

The interface slides to the full Labor board representation.

Resolution is then visualized directly on the scanned tabletop layout.

Once the engine reaches Ready to Roll again, the interface returns to Gameplay.

---

## 19. Labor Dice — Full View Presentation

**Status: LOCKED CONCEPT**

Compact gameplay tile:
- no literal gold Labor die required
- use `X/Y` health summary

Full Labor view:
- use literal/physical gold Labor dice on mapped card positions

Labor die health/value and track position are distinct dimensions and must animate independently.

### Preferred resolution behaviors

- damage → die rotates/tumbles downward through value change
- healing → die rotates upward while remaining on same node
- advancement → die moves along mapped track path
- branch → pause, highlight legal destinations, await player choice
- defeated die → remains visible at final node but becomes inactive/muted
- advance-other-die effect → triggering die completes movement/impact first, then secondary die advances

Detailed animation timing remains provisional.

---

## 20. Pending Decisions

**Status: LOCKED PRINCIPLE**

Meaningful player decisions interrupt automation.

Examples:
- branch choice
- Reward choice
- Mood decision
- broken-die choice
- resolve-anyway confirmation

Presentation may use:
- contextual highlighting
- bottom sheet
- overlay
- direct interaction on the full Labor board

The UI must not make meaningful optional decisions for the player.

---

## 21. UI / Engine Boundary

**Status: LOCKED — NON-NEGOTIABLE**

### Engine owns
- canonical state
- legal actions
- legal targets
- attack validation
- phase progression
- damage
- Labor impacts
- track movement
- branch legality
- Forecast results
- pending decisions
- random results
- victory/defeat

### UI may
- render canonical state
- render legal targets/actions
- collect player input
- submit player choices
- display Forecast
- animate accepted state transitions
- animate rejected placement attempts
- display pending decisions

### UI may not
- determine placement legality
- solve/partition attack requirements
- calculate damage
- determine phase advancement
- infer defeat
- generate randomness
- mutate canonical rules state independently

---


## 22. Global Menu and Undo Controls

**Status: LOCKED DIRECTION**

### Undo

Undo is a fixed control in the **bottom-left** of the Gameplay screen.

Bottom-bar structure:

`Undo | Dice Tray | Phase CTA`

Rules:
- Undo remains visible at all times on Gameplay
- Undo is dimmed/disabled when the engine reports no legal undo
- Undo is a compact square control rather than a full-width rail
- exact width remains provisional and must be stress-tested against the 11-die tray
- tapping Undo submits an engine-authorized undo request immediately
- no confirmation is required for a normal legal undo
- Undo may not cross the most recent committed random event
- Undo never rewinds RNG history or reuses random-event indices

Undo is not a generic UI-only back action.

### Dice Tray Impact

The Dice Tray occupies the center portion of the bottom bar between Undo and the Phase CTA.

If late-game tray density becomes too constrained:
- first adjust CTA/Undo widths within touch-target limits
- do not remove the stable Undo location without usability evidence

### Menu

Menu is a fixed control in the **top-right** corner of the persistent Status Tray.

Rules:
- Menu remains available at nearly all times, including automated Labor resolution and most pending-decision states
- opening Menu pauses presentation/interaction only
- opening Menu does not mutate canonical state
- pending mandatory decisions remain pending underneath the Menu
- destructive actions such as Restart/Quit may require their own confirmation flow later
- exact Menu icon and menu contents remain provisional

### Mood / Status Placement

The active Mood/status indicator occupies the Status Tray position immediately to the left of Menu.

Menu owns the top-right corner.


# Locked / Provisional / Open Summary

## Locked
- fixed bottom-left Undo control on Gameplay
- Undo remains visible and dims when unavailable
- bottom bar structure is Undo | Dice Tray | Phase CTA
- fixed top-right Menu control
- Mood/status sits immediately left of Menu
- Menu remains available at nearly all times and pauses presentation without mutating state
- portrait gameplay frame
- persistent Status Strip
- compact Forecast Strip only
- flexible central Action Grid
- no Labor name inside compact Labor tile
- 1/2/3/4 vertical Labor target-pane model
- Bow/Reward/actionable-effect shared tile system
- faint card artwork + card iconography
- phase dimming
- blue dice remain visually parked until Finish Blue
- reusable blue-used dice return to tray afterward
- Gold + Attack share one phase
- explicit Resolve Assignments
- combined Dice Tray + CTA Rail
- CTA becomes Unselect during loose selection
- drag-and-drop primary interaction
- tap-select secondary interaction
- legal-target highlighting across whole Action Grid
- scanned tabletop full Labor view
- resolution transitions to full Labor view
- literal gold Labor dice primarily in full Labor view
- UI never owns rules logic

## Provisional
- exact pixel heights
- exact tile sizes/aspect ratios
- exact sparse/dense grid templates
- CTA iconography
- exact die dimensions
- snapback-slot behavior
- inspect gesture details
- animation timing
- final visual theme/color treatment
- neutral Forecast treatment
- singleton bulk-attack optimization

## Open / Next Work
- precise assigned-bundle visual treatment inside compact Labor panes
- bundle movement/editing visuals
- detailed Labor-resolution animation choreography
- exact branch-choice presentation
- tutorial/first-time-user overlays
- accessibility pass
- final graphic design/theming
