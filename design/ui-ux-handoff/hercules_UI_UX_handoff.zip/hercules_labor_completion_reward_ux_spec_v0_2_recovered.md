# Hercules Digital Adaptation — Labor Completion & Reward UX Spec v0.2 — RECOVERED

**Recovery status:** Reconstructed from preserved project context, current Engine Execution Spec, Full Labor Resolution UX, and later implementation handoff.  
**Not guaranteed byte-for-byte identical to the lost original.**  
**Substantive locked decisions preserved where known; uncertain wording is intentionally avoided.**

## 1. Entry condition

Labor Completion begins only after:
- all required Labor dice are defeated/inactive,
- the current damage/resolution step is complete,
- the Resolution Tally has finished any still-open resource window,
- no earlier mandatory resolution work remains.

If the Labor is XII / Cerberus, use the separate Victory flow instead of normal Reward flow.

## 2. Completion beat

**LOCKED**

Remain in the Full Labor View for the completion beat.

Sequence:
1. current resolution finishes
2. camera settles on the defeated Labor presentation
3. `LABOR DEFEATED` appears
4. defeat beat holds briefly
5. Reward reveal begins

Do not jump immediately back to compact Gameplay.

## 3. Labor-card split transition

**LOCKED DIRECTION**

The defeated Labor presentation receives a strong diagonal lightning/crack treatment.

Preferred sequence:
- diagonal crack/lightning traverses the Labor card/presentation
- the defeated Labor presentation separates into two halves
- halves fall/slide toward lower corners
- Reward card(s) are revealed behind the defeated Labor

Exact physics/timing remain visual-polish details.

## 4. Reward reveal

Use verified physical Reward card art.

Do not digitally reinterpret Reward content beyond necessary interaction overlays.

### One Reward available

**LOCKED**
- give the Reward a short hero/reveal beat
- no meaningless confirmation is required
- engine acquires the sole Reward automatically
- continue to immediate Reward effects

### Multiple Rewards available

**LOCKED**
- show `CHOOSE A REWARD`
- all legal Reward choices remain visible
- player taps a Reward to highlight/select it
- bottom-left confirmation/checkmark control confirms the chosen Reward
- do not use a modal list if physical Reward cards are readable
- selection is not committed until confirmation

The engine owns legal Reward choices and final Reward acquisition.

## 5. Reward confirmation

**LOCKED**

On confirm:
- chosen Reward remains emphasized
- unchosen alternatives fade/recede
- chosen Reward expands/centers for a short acquisition beat
- engine persists the chosen Reward
- discarded/unselected alternatives are handled according to game rules

## 6. Immediate Reward bonuses

**LOCKED**

Any immediate Reward bonuses resolve after Reward acquisition and before transition to the next Labor.

Presentation:
- animate immediate Spirit/Divinity/resource benefits toward the persistent top Status Tray
- do **not** reopen the old Labor Resolution Tally for these new-Labor/progression bonuses
- canonical trackers update from engine-authoritative results

## 7. Reward-granted Hercules die

**LOCKED DIRECTION**

If acquisition grants an additional Hercules die:
- the next gameplay layout should already reserve the resulting tray geometry
- the new die appears during the return/progression transition
- no temporary fake physical die is created

The actual persistent die is engine state.

## 8. Mandatory Reward side effects

**LOCKED**

If the chosen Reward has a mandatory immediate side effect or required follow-up:
- stop progression as necessary
- present the engine-returned decision/effect
- resolve it before advancing to the next Labor

Do not bury required Reward work inside transition animation.

## 9. End active Labor state

**LOCKED**

After Reward resolution:
- completed Labor becomes persistent progression
- active Mood ends according to engine rules
- temporary Labor effects expire as defined by engine state
- prior-Labor broken Hercules dice are restored at the beginning of the next Labor, not invented by the UI

## 10. Next Labor transition

**LOCKED DIRECTION**

The defeated Labor tile is transitional only.

Preferred sequence:
1. Reward flow completes
2. defeated Labor presentation clears
3. next Labor tile slides down/enters beneath persistent top trays
4. short Labor Introduction Beat
5. Lore enters from bottom
6. Continue
7. Lore exits
8. Mood reveal enters from left
9. Mood resolves
10. Ready to Roll

Detailed Lore/Mood behavior belongs to the Mood Reveal & Setup UX Spec.

## 11. Final Labor exception

**LOCKED**

Cerberus does not use the normal Reward-acquisition ending.

After Cerberus completion, transition to the Victory / Hercules' Ascension flow.

## 12. UI / Engine boundary

### Engine owns
- whether the Labor is defeated
- Reward choice set
- Reward acquisition
- immediate Reward bonuses
- mandatory Reward side effects
- Mood cleanup
- persistent progression
- next-Labor state

### UI owns
- defeat beat
- crack/split presentation
- Reward card layout
- selection highlight
- confirmation affordance
- acquisition animation
- bonus-to-tracker animation
- next-Labor scene transition

The UI must never select a Reward for the player when more than one legal option exists.

## Recovered locked summary

- finish current resolution before Reward reveal
- `LABOR DEFEATED`
- diagonal crack/split defeated Labor presentation
- Reward cards appear behind Labor
- one Reward auto-acquires after reveal beat
- multiple Rewards require player selection + bottom-left confirm
- no generic modal
- chosen Reward expands; others fade
- immediate Reward bonuses animate to top trackers, not old tally
- Reward-granted Hercules die appears during progression transition
- mandatory Reward side effects resolve before progression
- next Labor enters before Lore/Mood flow
- Cerberus bypasses normal Reward flow
