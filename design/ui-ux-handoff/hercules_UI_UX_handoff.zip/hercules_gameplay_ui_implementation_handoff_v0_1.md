# Hercules Digital Adaptation — Gameplay UI Implementation Handoff v0.1

**Status:** Implementation-facing UI authority  
**Scope:** Main portrait gameplay screen, responsive layout behavior, compact Labor/action-grid composition, Reward/action tiles, persistent status area, Forecast/Resolution Tally, dice selection/assignment UX, Ferocious layout variants, Full Labor transition, and Figma handoff.

This document converts the approved UI/UX work into implementation constraints. It does **not** replace the deterministic rules engine or structured game content.

---

## 1. Authority and boundary

### Engine owns
- canonical game/player/Labor/dice state
- phase
- legal actions and legal targets
- placement legality
- Reward/Mood availability
- attack requirement validation
- Forecast projection
- resolution ordering
- pending decisions
- random results
- victory/defeat

### UI owns
- responsive layout
- visual state
- interaction affordances
- drag/tap presentation
- animation
- contextual controls
- projection of canonical state

The GUI must never independently interpret game rules or infer legality.

---

## 2. Figma visual authority

Primary Figma file:

https://www.figma.com/design/s0wKzNqI6DtcD5nD7fSLoV

Important pages / sections:
- `Components`
- `Reward Tile Component Family — v0.1`
- `Labor Layout Matrix — Base I–XII`
- `Labor Layout Matrix — Ferocious I–IX`
- `Reward Library — Full Set`

Use Figma as the approved visual/compositional reference.

### Authority relationship

The implementation contract defines responsive behavior, component semantics, interaction behavior, engine/UI responsibilities, minimum sizes, compression priorities, and state-driven layout rules.

Figma defines approved visual hierarchy, relative composition, representative density, tile anatomy, and intended proportions.

Do **not** reproduce Figma coordinates literally on every device. Preserve the design intent responsively.

---

## 3. Golden viewport and responsive model

Reference design viewport:

`390 × 844 logical px`

This is a **golden/reference viewport**, not a hard runtime size.

### Runtime vertical composition

Conceptually:

`safeTop + statusTray + forecastTray + actionGrid + bottomTray + safeBottom = viewportHeight`

The implementation should calculate the central Action Grid from the remaining available height.

### Working chrome ranges

Current Figma baseline:
- Status Tray: ~56 px
- Forecast Tray: ~36 px
- Bottom gameplay tray: ~150 px

Implementation tuning range:
- Status Tray: **56–64 px**
- Forecast Tray: **36–44 px**
- Bottom gameplay tray: **140–160 px**

The top trays may be enlarged slightly during device testing without re-authoring every Labor layout.

### Safe areas

Respect top notch/status-bar inset and bottom home-indicator inset. Do not allow safe-area handling to shrink interactive controls below minimum usable sizes.

---

## 4. Fixed/minimum dimensions vs flexible dimensions

Use a hybrid responsive system.

### Minimum/fixed interaction dimensions
- normal Hercules die footprint: **34 × 34**
- normal Reward ability placement slot: **34 × 34**
- occupied/shrunken duplicate slot/die: **17 × 17**
- compact assigned Labor attack die: **17 × 17** provisional baseline
- important touch controls: target approximately **44 × 44 minimum**
- gaps: nominal **6 px** at the reference viewport, may clamp slightly

### Flexible dimensions
- Action Grid height
- Labor tile height
- Reward/action tile width and height
- row/column distribution
- art crop
- name treatment
- internal padding

---

## 5. Fixed chrome, elastic center

Core layout rule:

> **Fixed chrome, elastic center.**

The top Status/Forecast area and bottom Dice Tray/CTA framework remain structurally stable. The Action Grid consumes the available middle region and is authored per Labor/density state.

Do not implement one global scale factor for the entire screen.

Do not implement the 12 Labors as 12 completely separate gameplay pages either.

Use shared reusable components, reusable responsive grid templates, and Labor-specific layout manifests/overrides where needed.

---

## 6. Status Tray

Persistent gameplay information:
- Labor number/name
- Spirit
- Divinity
- active Mood/status
- Menu
- secondary persistent-status indicators when mechanically useful

Menu remains fixed at top-right.

### Persistent-status cluster

Primary occupant:
- active Mood effect indicator

Additional approved candidates:
- **Zeus' Disregard B available/owned state**
- **Cannot Block / No Block** when active for the current round

Use this area only for persistent state whose omission could cause a misleading or illegal interaction. Do not turn it into a general event log.

### Zeus' Disregard B

Zeus B is persistent owned Reward state, but it does **not** require a normal Action Grid tile.

Presentation:
- compact top-status indicator while relevant/available
- during Mood reveal, if engine says redraw is legal, show contextual redraw control on the Mood card
- after consumption/unavailability, update or remove the persistent indicator according to engine state

---

## 7. Forecast Strip / Resolution Tally

### Gameplay state: Forecast

The Forecast is one compact row showing deterministic consequences of the **current valid committed assignment state**.

Rules:
- engine supplies the projection
- loose selected dice do not change Forecast
- unplaced candidate attacks do not change Forecast
- valid committed placements update immediately
- rejected/illegal placements do not change Forecast
- zero-value categories may disappear
- no strategic recommendation text

### Full Labor resolution state: Resolution Tally

The same screen region becomes the Resolution Tally.

Behavior:
- initialize with committed Gold contributions
- append Labor/resource contributions as resolution proceeds
- keep tally open through normal Labor movement and triggered cascades
- apply net Spirit/Divinity to persistent trackers once the resolution window closes

---

## 8. Action Grid contents

The Action Grid may contain:
- compact current Labor tile
- currently owned actionable Reward tiles
- Bow only if currently owned
- temporary actionable effect tiles such as Ferocious

It does **not** contain:
- a permanent Mood tile
- passive statuses that do not create a player-facing action
- Zeus B as a normal gameplay action tile

### Bow

Bow is a Reward and is removable like other prior Rewards. Do not hard-code Bow as permanent.

---

## 9. Compact Labor tile

The compact Labor tile is the primary attack-assignment surface.

Do not repeat the Labor name inside the tile.

Each independently damageable Labor die gets one vertical target pane:
- 1 Labor die → 1 pane
- 2 → 2 panes
- 3 → 3 panes
- 4 → 4 panes

Each pane minimally shows:
- `current / starting health`
- attack requirement iconography/content
- next-node effect iconography

The source for attack requirement text/iconography is authoritative structured Labor content, not this UI specification.

Shared Labor-wide requirements should appear once where practical. Defeated/inactive panes remain spatially present and visually retired.

---

## 10. Per-Labor authored layout manifests

The Figma `Labor Layout Matrix` is the visual reference.

Runtime layout should be driven by a manifest rather than absolute Figma coordinates.

Recommended manifest shape:

```ts
type LaborGameplayLayoutManifest = {
  laborId: string;
  paneCount: 1 | 2 | 3 | 4;
  laborRegion: {
    targetHeightRatio: number;
    minHeight: number;
    maxHeight: number;
    sharedRequirementBand?: boolean;
  };
  actionGrid: {
    preferredColumns: number;
    preferredRows: number;
    gap: number;
    denseMode?: boolean;
  };
  bundle: {
    compactDieSize: number;
    horizontal: true;
    sort: "face_asc_then_die_id";
  };
  ferociousVariant?: {
    extraTile: true;
    preferredPlacement: "authored";
  };
};
```

### Reference density by Labor

This is the approved **reference-density study**, not a rule that the player must own exactly this many Rewards.

| Labor | Pane count | Reference action-tile count | Ferocious study |
|---|---:|---:|---:|
| I | 1 | 1 | 2 |
| II | 1 | 2 | 3 |
| III | 1 | 3 | 4 |
| IV | 2 | 4 | 5 |
| V | 2 | 5 | 6 |
| VI | 4 | 5 | 6 |
| VII | 1 | 6 | 7 |
| VIII | 2 | 6 | 7 |
| IX | 3 | 7 | 8 |
| X | 4 | 8 | n/a |
| XI | 2 | 8 | n/a |
| XII | 3 | 9 | n/a |

Actual runtime tile count comes from canonical state. Reward removal, Bow removal, and chosen Reward variants can reduce the count. Ferocious adds one temporary actionable tile only when active.

---

## 11. Responsive Action Grid behavior

### Sparse states
Use larger Labor and Reward/action tiles. Avoid dead space.

### Dense states
Compress tile size progressively while preserving, in order:
1. legal target visibility
2. die-slot readability
3. touchability
4. attack-bundle readability
5. art/name information

### Compression priority
1. reduce decorative padding
2. shorten/omit Reward text labels
3. reduce visible art crop
4. reduce tile height/width within manifest clamp
5. use 17×17 compact occupied/assigned states where specified

Do **not** shrink interactive empty die slots below the normal 34×34 footprint unless a separately tested compact mode is explicitly introduced.

---

## 12. Reward/action tile anatomy

Common family:
- muted physical Reward art/background
- compact Reward identity/name when space permits
- Blue and/or Gold placement locations
- original iconography where practical
- placement locations low/centered to preserve art

All Reward die locations remain visible regardless of current phase. Phase changes affect active/legal state, not basic visibility.

### Blue + Gold
Blue and Gold locations are separate visible targets.

### Same-type ×2
Preferred dynamic treatment:
- first available slot full 34×34
- secondary identical slot may appear compact
- after first use, occupied slot/die shrinks to 17×17
- remaining unused slot grows/stays 34×34

### Copy-die abilities
Regret B and Blood of the Amazons A share the same UI treatment:
- show `1 → 2` or equivalent two-dice symbol depending available space
- source physical die remains one die
- derived contribution is visually distinguishable but interacts like a die for allowed placement
- source↔copy relation remains inspectable
- do not duplicate the physical die canonically

### Pholus
Pholus does not occupy a permanent additional grid slot after choice.

During Mood resolution:
- Mood card becomes tile-sized
- player drags it onto a legal Reward
- it overlays/covers that Reward
- covered Reward is visually disabled
- overlay remains for the Labor

---

## 13. Ferocious layout variants

Ferocious creates:
- persistent Mood/status indication
- one temporary actionable **Blue** tile

The Figma `Labor Layout Matrix — Ferocious I–IX` is the visual authority for the additional tile.

Do not simply shrink the base grid uniformly and append Ferocious. Each Ferocious layout is an authored variant of the corresponding Labor density state.

---

## 14. Dice Tray + CTA rail

Bottom region is:

`Undo | Dice Tray | Phase CTA`

### Undo
- fixed bottom-left
- dim/unavailable when engine says undo is illegal

### Dice Tray
- center region
- supports full legal Hercules-dice range
- one row at low count
- two rows at high count
- 11 dice must remain legible/selectable
- parked/assigned dice leave the tray visually

### CTA states

No loose selection:
- Ready to Roll → Roll
- Blue → Finish Blue
- Gold + Attack → Resolve Assignments

Loose dice selected:
- CTA becomes **Unselect**

---

## 15. Dice selection and placement

Primary interaction: drag/drop.  
Secondary interaction: tap-select / tap-target.

Rules:
- tap unselected die → add to loose selection
- tap selected die → remove from loose selection
- one loose selection at a time
- dragging any selected die moves the entire selected set
- tapping empty background does not clear selection
- legal targets are returned by the engine and highlighted in the action surface
- tray itself does not label the current selection valid/invalid

---

## 16. Attack-bundle contract

One selection = one proposed attack group.

The UI must never automatically partition a selected set into multiple attacks.

### Drag presentation
At drag start:
- selected dice form one horizontal row
- sort ascending face
- ties use stable die ID
- touch point is centered on the group, not permanently bound to initiating die

### Valid placement
After successful Labor placement:
- group remains a distinct bundle
- shrink each die to reference 17×17
- preserve horizontal sorted order
- do not merge multiple bundles on the same target

### Invalid placement
- reject
- snap back
- selection remains active
- no modal

### Editing an assigned bundle
- tap bundle → select whole bundle
- drag whole bundle
- Dice Tray is a legal remove-assignment destination where engine allows
- returning to tray restores physical dice and clears bundle grouping
- no per-die editing inside an already committed visual bundle

---

## 17. Blue phase behavior

Blue spaces active; Gold/Labor targets inactive.

A die used on a Blue ability:
- remains visibly parked on that tile for the Blue phase
- immediately reflects any manipulated face
- is not automatically treated as spent

On Finish Blue:
- reusable blue-used dice return to tray with manipulated values intact
- actually spent/removed dice do not return

UI must preserve:

`blue_used != spent`

---

## 18. Gold + Attack behavior

After Blue:
- Blue targets dim
- Gold targets activate
- Labor target panes activate

Individual placement never ends the phase.

Phase ends only through explicit `Resolve Assignments`.

If engine returns an unused-meaningful-placement confirmation checkpoint, show compact confirmation. This is separate from invalid placement rejection.

---

## 19. Full Labor View

When Resolve Assignments is accepted:

`Gameplay View → Full Labor View`

Full Labor presentation uses verified physical Labor card scans/images with presentation overlays.

Each Full Labor manifest may define:
- source scan/image
- card rectangles/orientation
- normalized track-node coordinates
- Labor-die scale
- branch hit areas
- camera overview
- camera active-die framing
- multi-card arrangement

The engine remains unaware of camera geometry.

### Resolution
- damage before advancement
- defeated Labor die remains on final node, visually retired/stone
- normal multi-die advancement follows engine stable order
- branch decisions stop automation and highlight legal board targets
- node impacts append to Resolution Tally
- triggered advance-other effects resolve after normal pass as engine specifies
- tally closes only after the full resource-resolution window

### Return
After resolution, if Labor continues:
- remain in inspectable Full Labor view
- player explicitly returns to gameplay
- next roll occurs only from gameplay view

---

## 20. Persistent status semantics

Recommended runtime model:

```ts
type PersistentStatusItem =
  | { kind: "mood"; id: string; iconKey: string; inspectable: true }
  | { kind: "zeus_disregard"; available: boolean; inspectable: true }
  | { kind: "cannot_block"; active: boolean; expiresAt: "round_cleanup"; inspectable: true };
```

The engine supplies the state. The UI does not infer it from board position.

---

## 21. Implementation data contract

Recommended screen projection:

```ts
type GameplayScreenModel = {
  viewportClass: {
    width: number;
    height: number;
    safeTop: number;
    safeBottom: number;
  };
  phase: string;
  labor: {
    id: string;
    numberLabel: string;
    name: string;
    panes: LaborPaneViewModel[];
    layoutManifestId: string;
  };
  player: {
    spirit: number;
    divinity: number;
  };
  statuses: PersistentStatusItem[];
  forecast: ForecastProjection;
  actionTiles: ActionTileViewModel[];
  dice: HerculesDieViewModel[];
  looseSelection: string[];
  legalTargets: string[];
  undoAvailable: boolean;
  phaseCta: "ROLL" | "FINISH_BLUE" | "RESOLVE_ASSIGNMENTS" | "UNSELECT";
};
```

Render from this projection. Do not put gameplay rules inside React components/UI widgets.

---

## 22. Required implementation tests

### Responsive
Test at minimum:
- reference 390×844
- short/narrow modern phone
- tall modern phone
- device with large safe-area insets

Verify:
- top chrome may expand without breaking Action Grid
- 34×34 empty slots remain usable
- 11 dice remain selectable
- dense Cerberus state remains readable
- Ferocious variants remain non-overlapping

### Interaction
Test:
- one die selection
- multi-die bundle
- invalid bundle
- multiple bundles on one target
- move assigned bundle
- remove bundle to tray
- Blue parked die return
- copy/derived die contribution
- same-type ×2 occupied state
- Pholus covered Reward
- Zeus B Mood redraw
- Cannot Block status visibility
- resolve-anyway confirmation

### Labor density
Regression snapshots:
- Birds
- Apples
- Cattle
- Cerberus
- at least one Ferocious dense state

---

## 23. Provisional implementation-tuning items

These may be tuned after first on-device build without reopening the core layout design:
- Status Tray exact height within the working range
- Forecast Tray exact height within the working range
- exact typography size
- exact card-art opacity
- exact Reward-name truncation threshold
- exact compact-gap clamp
- exact animation timing
- exact iconography for Ferocious / Zeus / Cannot Block

Any tuning must preserve interaction semantics, minimum target sizes, legal target visibility, fixed-chrome/elastic-center behavior, and per-Labor layout hierarchy.

---

## 24. Completion criterion for this handoff

The gameplay UI is implementation-ready when Codex can:

1. render the 390×844 reference state against Figma
2. adapt the same state to other phone sizes using this responsive model
3. switch Labor layout by manifest
4. add/remove Reward/action tiles from canonical state
5. add Ferocious without overlap
6. render legal-target highlighting from engine output
7. render Forecast from engine output
8. maintain all dice/placement interactions without implementing rules in the GUI
9. enter/exit Full Labor resolution correctly
10. display Mood + Zeus B + Cannot Block persistent status state

At that point, further work should move to device testing, accessibility, tutorial/onboarding, animation polish, and visual-theme refinement rather than additional structural mockup work.
