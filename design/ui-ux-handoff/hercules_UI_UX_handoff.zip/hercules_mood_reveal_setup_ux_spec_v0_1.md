# Hercules Digital Adaptation — Mood Reveal & Setup UX Spec v0.1

**Status:** Working UI authority  
**Scope:** Mood reveal, Mood-specific decisions, persistent Mood representation, temporary action-surface changes, temporary dice-pool changes, Zeus' Disregard redraw presentation, and handoff into Ready to Roll.

This specification governs presentation and interaction only. The deterministic engine remains authoritative for Mood draw order, redraw legality, Mood effects, pending player decisions, temporary dice-pool changes, Reward blocking, and phase progression.

## 1. Entry Point
**Status: LOCKED**

Mood reveal begins after the new Labor tile has entered and the Labor Introduction Beat has completed.

Sequence:
1. Labor Introduction Beat fades
2. Mood card slides in from the left
3. Mood card settles in a centered reveal position
4. physical Mood-card image is shown at readable size
5. any legal redraw/choice interaction is presented
6. Mood resolves
7. persistent Mood representation is established
8. temporary gameplay-surface or dice-pool changes animate into place
9. progression continues toward Ready to Roll

## 2. Base Mood Reveal
**Status: LOCKED**

For the current demo, use the physical Mood-card image. The card slides in from the left and settles centered in the gameplay area. No modal/pop-up framing is used.

## 3. Persistent Mood Representation
**Status: LOCKED**

After resolution, the active Mood is represented persistently at the far right of the top Status Tray.

The indicator communicates the active mechanical effect rather than just the Mood name.

Examples:
- Spirit loss: `-#` + Spirit icon
- Hercules-die loss/gain: `-# / +#` + die icon
- all-dice pip modifier: `-1` or `+1` + die-face icon
- Ghost of Hippolyta: barred/prohibited `1`
- Ghost of Pholus: small diagonally torn-card symbol
- Ghost of Abderus: the chosen consequence
- Ferocious: custom symbol to be defined later

## 4. Passive Immediate Moods
**Status: LOCKED DIRECTION**

Reveal → resolve effect → animate resource/dice change → transition card out of center → persistent Status Tray icon appears.

Exact card-to-tray animation is provisional.

## 5. Temporary Dice-Pool Mood Effects
**Status: LOCKED**

If a Mood temporarily adds/removes Hercules dice:
- Dice Tray changes to the temporary Labor geometry before Ready to Roll
- added dice visibly enter
- removed dice visibly leave
- persistent Mood indicator remains visible

## 6. Ferocious / Temporary Actionable Mood
**Status: LOCKED DIRECTION**

If a Mood creates an actionable Blue ability:
1. Mood resolves
2. persistent Mood icon appears
3. temporary Blue action space/tile is added to the Action Grid
4. it follows normal phase dimming and legal-target highlighting
5. it remains only for the active Labor

## 7. Ghost of Abderus
**Status: LOCKED**

The physical Mood card itself is the choice surface:
1. card reveals
2. short prompt appears
3. two printed choice regions become selectable
4. player taps one
5. engine commits choice
6. selected option gets brief confirmation treatment
7. effect resolves
8. card transitions away
9. Status Tray icon reflects the chosen consequence

## 8. Ghost of Pholus
**Status: LOCKED**

1. Mood card reveals
2. card shrinks into an action-tile-sized draggable object
3. legal Reward targets highlight
4. player drags Pholus over the Reward to disable
5. engine commits choice
6. Pholus becomes a visible overlay/cover on that Reward
7. torn-card Mood icon appears in Status Tray

## 9. Ghost of Hippolyta
**Status: LOCKED DIRECTION**

After reveal, persistent Status Tray treatment uses a barred/prohibited `1`. No separate action tile is created.

## 10. Zeus' Disregard Redraw
**Status: LOCKED**

If redraw is legally available, after Mood reveal but before effect resolution:

- a narrow full-width button appears across the top edge of the Mood card
- button text is: **Redraw Mood with Zeus' Disregard**
- bottom CTA accepts/continues with the current Mood
- there is no second redraw confirmation

If redraw is chosen:
1. current Mood is rejected by the engine
2. current card animates away
3. replacement Mood slides into the same centered reveal position
4. redraw option is consumed/unavailable unless engine state explicitly says otherwise
5. player continues with the replacement Mood

The UI does not shuffle or draw independently.

## 11. Mood Card Exit
**Status: LOCKED DIRECTION**

Ordinary Moods transition from the large centered card into their persistent status representation. Exact shrink/fade path is provisional.

Pholus is the exception because it becomes a draggable cover tile first.

## 12. Mood Setup Completion
**Status: LOCKED**

Mood setup is complete only after:
- mandatory Mood choices are resolved
- temporary dice-pool changes are reflected
- temporary action tiles are present
- Reward blocking is reflected
- persistent Mood indicator is present
- no pending mandatory Mood decision remains

Then progression may continue to Ready to Roll.

## 13. End-of-Labor Mood Cleanup
**Status: PROVISIONAL**

At Labor end, clear Mood-specific presentation as engine state ends the Mood:
- remove Status Tray Mood icon
- remove temporary Mood action tile
- restore covered Reward after Pholus
- restore temporary dice-pool changes
- clear Labor-only Mood presentation

Exact cleanup animation remains deferred.

## 14. UI / Engine Boundary
**Status: LOCKED — NON-NEGOTIABLE**

### Engine owns
- Mood draw/order
- redraw legality/replacement
- Mood effect resolution
- Abderus choice legality
- Pholus Reward-choice legality
- temporary dice-pool changes
- temporary action availability
- Reward blocking
- Mood cleanup
- phase progression

### UI owns
- reveal animation
- physical-card presentation
- choice-region highlighting
- Zeus redraw button presentation
- persistent Status Tray Mood icon
- Pholus drag presentation
- temporary Mood tile rendering
- dice-pool change animation
- Mood exit/cleanup animation

The UI must never draw, redraw, shuffle, resolve, or interpret Mood legality independently.

# Locked / Provisional / Open Summary

## Locked
- Mood reveal follows Labor Introduction Beat
- Mood card slides in from left to center
- physical card image used for demo
- active Mood persists as far-right Status Tray icon
- persistent icon communicates effect
- temporary dice-pool changes animate before Ready to Roll
- Ferocious adds a temporary Blue action tile
- Abderus uses selectable regions on physical card
- Abderus status reflects chosen consequence
- Pholus becomes a draggable cover tile
- Pholus also gets a torn-card status icon
- Hippolyta uses barred/prohibited `1`
- Zeus redraw uses explicit top-of-card button
- button text: `Redraw Mood with Zeus' Disregard`
- bottom CTA accepts current Mood
- no second redraw confirmation
- replacement Mood animates into same reveal position
- UI does not own Mood logic

## Provisional
- exact centered-card size
- exact card-to-status transition
- exact Mood iconography
- exact Ferocious art
- exact Pholus cover art
- exact temporary dice enter/exit animation
- Mood cleanup animation

## Open / Next Work
- global Undo control
- global Menu control
- detailed Mood cleanup transition testing
- accessibility treatment
- visual/theme pass
