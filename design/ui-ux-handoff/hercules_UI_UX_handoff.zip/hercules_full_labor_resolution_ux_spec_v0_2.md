# Hercules Digital Adaptation — Full Labor Resolution UX Spec v0.2

**Status:** Working UI authority  
**Scope:** Full Labor View presentation, resolution sequencing, Labor-die animation, resource tally behavior, track movement, branch choices, node-effect visualization, triggered advancement, defeated-die treatment, and return-to-gameplay behavior.

This specification governs presentation and interaction only, except where it identifies required engine sequencing clarifications necessary for the UI to reflect authoritative game state correctly. The deterministic engine remains authoritative for canonical state, effect ordering, track movement, resource resolution, pending decisions, and failure/victory outcomes.

---

## 1. Full Labor View as a Presentation Canvas

**Status: LOCKED DIRECTION**

The Full Labor View is not required to display the entire physical Labor layout inside the portrait phone viewport at all times.

Instead, each Labor is rendered on a Labor-specific presentation canvas larger than the viewport, with the phone acting as a movable camera.

Each Labor presentation manifest may define:
- source scan/image assets
- card rectangles
- card rotation/orientation
- normalized track-node coordinates
- Labor-die scale
- branch hit areas
- overview camera framing
- active-die camera framing
- special multi-card arrangement
- landscape-card arrangement

This model must support single portrait cards, multiple-card Labors, wide/landscape Labors, irregular arrangements, and future mobile-specific artwork without changing engine semantics.

The engine remains unaware of camera geometry and source-image dimensions.

## 2. Camera and Navigation Behavior

**Status: LOCKED**

The Full Labor View supports automatic camera framing during resolution and direct player navigation during post-resolution inspection.

### Automated resolution state

During automated resolution:
- camera framing is engine-state-driven presentation
- the active Labor die, destination, and relevant effect context remain visible
- ordinary manual pan/zoom is suppressed so the player does not accidentally fight the camera
- the player should not need to manually chase an animation

### Post-resolution inspect state

Once the engine reaches the continuing-Labor Ready state:
- one-finger drag pans the Labor presentation canvas
- two-finger pinch outward zooms in
- two-finger pinch inward zooms out
- double-tap fits the entire Labor presentation canvas to the viewport
- pan/zoom operates only on the Labor board canvas; fixed UI chrome does not move

A dedicated persistent Fit Board button is not required for the initial design. Double-tap is the primary fit-to-board gesture. A visible Fit Board control remains an accessibility/usability fallback if testing shows the gesture is insufficiently discoverable.

A one-time helper tip may teach: `Double-tap to view the full Labor.`

No minimap is required unless later testing demonstrates a navigation problem.

### Mandatory decision priority

When a branch choice or other mandatory board-level decision is active:
- legal decision targets take interaction priority
- free board navigation may be limited as needed to prevent accidental choice/pan conflicts
- the player may not leave the Full Labor View while a mandatory decision remains unresolved

### Return to Gameplay

A fixed **Return to Gameplay** control is anchored at the **bottom-left** of the Full Labor View.

Rules:
- the control is screen-fixed and never moves with pan/zoom
- it is available whenever the UI is in an inspectable/non-mandatory-decision state
- it is unavailable while a mandatory decision is unresolved
- an optional swipe-back gesture may perform the same action
- swipe-back is secondary; the visible bottom-left control is the primary navigation method

The top screen area remains reserved for the persistent Status Tray and Resolution Tally.

## 3. Transition Into Labor Resolution

**Status: LOCKED**

When `Resolve Assignments` is accepted:

`Gameplay View → Full Labor View`

The full presentation shifts laterally as a scene transition.

The Full Labor View visually preserves the same top status structure from Gameplay:
- current Labor identifier
- Mood/status
- Spirit
- Divinity

The Gameplay Forecast strip remains in the same visual location and frame, but changes function into the **Resolution Tally**.

## 4. Resolution Tally Initialization

**Status: LOCKED**

Before Labor movement begins, the Resolution Tally is pre-populated with all already-committed Gold effects that contribute to the current resource-resolution window.

Example:

`1 [Block] + 2 [Spirit Gain] = +3 [Spirit]`

Gold contributions appear immediately when the Full Labor View arrives. The persistent Spirit/Divinity trackers do not change yet.

## 5. Damage Phase

**Status: LOCKED DIRECTION**

Committed attack damage resolves before Labor advancement.

Where independent Labor dice take damage in the same damage phase, their health-change animations may occur simultaneously.

Labor-die health changes are represented by rotating/tumbling the physical gold Labor die to its new value. Track position does not change during health animation.

## 6. Labor Defeat Check Before Advancement

**Status: LOCKED**

After attack damage:
- any Labor die reduced to 0 becomes defeated/inactive
- if all required Labor dice are defeated, the Labor is defeated
- no Labor advancement occurs in that case

## 7. Defeated Labor Die — Full View

**Status: LOCKED**

A Labor die reduced to 0 remains physically on its final canonical track node.

Because a physical six-sided die has no zero face:
- the die remains visually on its final `1` face
- its material appearance transforms from active gold into an aged/cracked gray-stone state
- it loses active glow/highlight treatment
- it no longer moves or receives active-effect presentation

The compact Labor pane shows `0 / Y` and becomes muted/inactive while remaining spatially present.

## 8. Normal Multi-Labor-Die Advancement Pass

**Status: LOCKED DIRECTION / ENGINE-SEQUENCING REQUIREMENT**

For a continuing multi-die Labor, the normal end-of-round advancement pass is processed in stable visual order:
- left-to-right
- then top-to-bottom where applicable

Each normally scheduled active Labor die completes:
1. branch decision if one exists
2. movement
3. landing
4. node-effect reveal
5. immediate non-resource effect processing
6. resource contribution into the still-open Resolution Tally

The UI animation order mirrors the engine's authoritative stable order.

## 9. Branch Choices

**Status: LOCKED**

If an active Labor die has multiple legal outgoing edges:
- do not begin movement yet
- active die subtly lifts/pulses
- irrelevant board regions may dim slightly
- legal destination nodes highlight
- legal connecting paths may highlight
- player chooses directly on the Labor board
- engine commits the branch choice
- movement animation proceeds

Avoid generic modal presentation unless the physical board geometry is genuinely unreadable.

## 10. Track Movement Animation

**Status: LOCKED DIRECTION**

Labor-die advancement should visibly follow the mapped track path.

Preferred movement:
- die lifts slightly
- follows an eased path to destination
- may rotate subtly while moving
- settles centered on destination node

Movement and health remain visually distinct:
- face rotation = health
- position change = track advancement

## 11. Node Effect Hidden Under Labor Die

**Status: LOCKED**

Because the Labor die physically covers the printed node:
1. Labor die lands and settles
2. destination node briefly brightens through/around the die
3. enlarged node iconography appears over or just above the die
4. Labor die becomes slightly muted/translucent behind the overlay
5. effect overlay pulses
6. effect is attributed/resolved
7. overlay fades
8. die returns to normal active opacity

The Labor die never moves aside merely to reveal the icon.

For multiple-icon nodes, show the complete icon group first, then animate each engine-returned effect in authoritative order.

## 12. Resource Contributions During Movement

**Status: LOCKED**

Spirit/Divinity changes arising from Labor movement do not immediately change the persistent trackers.

Instead, each resource source is appended to the Resolution Tally as that node resolves.

The running total updates after each contribution.

## 13. Resource Provenance

**Status: LOCKED**

The Resolution Tally preserves source type:
- Block remains distinct from Spirit gain
- Spirit gain remains distinct from Spirit loss
- Divinity gain/loss uses its own symbols
- individual Labor-die contributions append in resolution order

The tally is a compact explanation of how the final result was produced, not merely a final number.

## 14. Effect-to-Tally Visual Language

**Status: LOCKED DIRECTION**

When a Labor die produces a resource effect:

`Labor die / node overlay → Resolution Tally`

Preferred presentation may use lightning, energy arc, traveling icon, or other thematic connection.

Do not send each source directly to the persistent Spirit/Divinity tracker.

## 15. Healing

**Status: LOCKED**

Healing resolves immediately when its node effect is processed:
1. heal overlay pulses
2. Labor die rotates upward to its new health value
3. die remains on the same track node

## 16. Breaking Hercules Dice

**Status: LOCKED**

The engine resolves broken-Hercules-die identity automatically and deterministically when identity has no mechanical relevance.

No player choice is required for current verified content.

Visual sequence:
1. break-Hercules-die node overlay pulses
2. engine-selected Hercules die is visually identified
3. that die receives a broken/cracked/dim treatment
4. persistent broken-die status updates
5. resolution continues automatically

## 17. `Advance All Other Labor Dice` — Trigger Queue

**Status: LOCKED DIRECTION / ENGINE-SEQUENCING REQUIREMENT**

`Advance all other Labor dice` does not interrupt the normal advancement pass.

Instead:
1. source Labor die completes normal movement and arrival processing
2. advance-other effect is enqueued
3. remaining normally scheduled Labor dice finish their normal movement/arrival processing
4. after the normal pass, queued advance-other triggers execute FIFO in source order

When a trigger executes:
- snapshot all other active Labor dice eligible at that moment
- exclude the source die
- exclude defeated/inactive Labor dice
- advance affected dice in stable visual order
- resolve each triggered arrival normally
- enqueue any newly created advance-other triggers at the end of the queue

Continue until the trigger queue is empty.

## 18. Birds Reference Model

**Status: REFERENCE INTERACTION MODEL**

For A, B, C, D where C lands on `Advance all other Labor dice`:

Normal pass:
- A moves and resolves
- B moves and resolves
- C moves and resolves; enqueue C's advance-other trigger
- D moves and resolves

Then C's trigger executes:
- A advances again if active
- B advances again if active
- D advances again if active

Triggered arrivals may add further resource contributions, healing, break effects, branches, skulls, or additional queued advancement triggers.

## 19. Resolution Tally Remains Open Across the Entire Cascade

**Status: LOCKED**

The tally remains open through:
- pre-populated Gold contributions
- all normal Labor-die movement
- all normal arrival effects
- all queued triggered movement
- all triggered arrival effects
- any nested advancement cascade

Do not finalize Spirit/Divinity before the movement/trigger queue is empty.

## 20. Final Resource Application

**Status: LOCKED**

Only after the complete movement cascade ends does the engine close the resource-resolution window.

Then:
1. final Spirit tally is emphasized
2. final Divinity tally is emphasized
3. engine calculates/applies authoritative net deltas
4. one final visual connection travels from tally to persistent tracker
5. persistent Spirit/Divinity trackers update once
6. tally settles/clears

## 21. Non-Resource Effects Do Not Enter the Tally

**Status: LOCKED**

The Resolution Tally is specifically for nettable resource consequences.

Other effects resolve through direct presentation:
- Heal → Labor die rotates upward
- Break Hercules die → broken-die animation/state
- Advance others → trigger queue
- Cannot Block → status treatment
- Skull → failure flow

The tally is not a generic event log.

## 22. Cannot Block

**Status: LOCKED DIRECTION**

Cannot Block is treated as an ongoing status rather than immediate resource damage.

When entered:
- node overlay pulses
- persistent restriction/status indication appears as appropriate
- UI reflects authoritative engine timing
- entering during resolution does not retroactively alter the round already being resolved

## 23. Skull / Failure

**Status: LOCKED PRINCIPLE**

If a Labor die reaches a skull/failure node:
- die completes movement to the skull
- skull receives strong board-level emphasis
- engine resolves failure at authoritative timing
- normal return-to-gameplay flow is interrupted

Detailed defeat presentation remains a later design task.

## 24. End-of-Resolution Ready State

**Status: LOCKED**

If all resolution work is complete, no pending decision remains, no Labor/game defeat occurred, and the engine reaches `READY_TO_ROLL`, the Full Labor View remains open.

The UI does not automatically return to Gameplay.

## 25. Post-Resolution Inspection

**Status: LOCKED**

Once resolution completes:
- auto-follow camera stops
- one-finger pan becomes active
- pinch-to-zoom supports both zoom in and zoom out
- double-tap fits the full Labor presentation canvas to the viewport
- Labor dice sit on their new nodes
- final Spirit/Divinity totals remain visible
- temporary resolution highlights are cleared
- player may inspect future track consequences before the next roll

## 26. Returning to Gameplay

**Status: LOCKED**

The player explicitly returns to Gameplay through:
- a fixed bottom-left Return to Gameplay control
- optional swipe-back gesture

The bottom-left control is primary. Swipe is secondary.

The control remains screen-fixed regardless of board pan/zoom and is unavailable while a mandatory decision is unresolved.

The next roll can be initiated only from Gameplay.

## 27. Labor Defeat Exception

**Status: LOCKED**

If all required Labor dice are defeated:
- do not enter post-resolution Ready inspection
- transition into Labor-completion / Reward flow

Reward-flow UX is a separate workstream.

## 28. Game Defeat Exception

**Status: LOCKED**

If an explicit game-defeat condition occurs:
- do not return to normal Gameplay
- enter the defeat flow

Detailed defeat UX remains open.

## 29. Presentation Speed Architecture

**Status: PROVISIONAL BUT REQUIRED FOR ARCHITECTURE**

Future presentation modes may include:
- Normal
- Fast
- Instant

Speed affects presentation timing only. It must never alter canonical transition order, resource semantics, RNG, pending decisions, branch legality, or effect sequencing.

## 30. UI / Engine Boundary

**Status: LOCKED — NON-NEGOTIABLE**

### Engine owns
- damage results
- defeated/inactive state
- normal advancement order
- branch legality
- trigger queue semantics
- effect ordering
- resource-resolution window
- Spirit/Divinity net results
- break-die selection
- failure checks
- READY_TO_ROLL transition

### UI owns
- camera movement
- scan/image layout
- gold Labor-die rendering
- damage/heal rotation animation
- movement animation
- node-effect overlays
- tally visualization
- thematic source-to-tally effects
- defeated-die material treatment
- post-resolution pan/zoom
- scene transitions

The renderer may visualize engine transitions but must never invent or reorder game semantics independently.

---

# Locked / Provisional / Open Summary

## Locked
- Full Labor View uses a Labor-specific pan/zoom presentation canvas
- multi-card and landscape Labors need not fit entirely in the portrait viewport at once
- automatic camera framing during resolution
- manual navigation suppressed during automated resolution
- branch/mandatory decision targets take priority over board navigation
- top area reserved for Status Tray + Resolution Tally
- no minimap unless testing demonstrates a need
- one-finger pan, pinch zoom in/out, and double-tap fit-to-board during inspection
- top status tray remains visually continuous across transition
- Forecast strip becomes Resolution Tally
- Gold resource/block contributions pre-populate tally
- Labor-die health and position animate separately
- independent damage may animate simultaneously
- normal advancement is sequential in stable visual order
- branches stop before movement and are chosen directly on board
- node effect appears as enlarged overlay above temporarily muted Labor die
- resource contributions append to tally one source at a time
- tally remains open through all triggered movement
- final Spirit/Divinity applied once after cascade completes
- Break Hercules die auto-resolves deterministically
- Advance Other Labor Dice uses post-normal-pass FIFO trigger queue
- defeated Labor die remains at final node
- defeated full-view die remains on face 1 but becomes aged/cracked stone/gray
- compact defeated pane shows 0/Y
- Full Labor View remains open after continuing-Labor resolution
- fixed bottom-left Return to Gameplay control; optional swipe-back
- next roll is available only from Gameplay
- UI does not own rules logic

## Provisional
- exact camera easing and zoom levels
- exact tally typography/equation layout
- exact lightning/energy visual treatment
- exact cracked-stone art treatment
- exact Return to Gameplay icon treatment
- exact animation timing
- Fast/Instant presentation details

## Open / Next Work
- Reward-selection / Labor-completion flow
- game-defeat presentation
- accessibility treatment for animated effects
- final graphic-design/theme pass
- implementation-level event/animation contract
