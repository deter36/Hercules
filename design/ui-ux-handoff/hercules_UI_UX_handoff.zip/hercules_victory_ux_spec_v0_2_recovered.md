# Hercules Digital Adaptation — Victory UX Spec v0.2 — RECOVERED

**Recovery status:** Reconstructed from preserved project context, verified Ascension image reference, Engine Execution Spec, and later implementation handoff.  
**Not guaranteed byte-for-byte identical to the lost original.**

## 1. Entry condition

**LOCKED**

Victory flow is entered only after the engine confirms the final Cerberus/endgame victory requirements.

Normal Labor Reward flow is bypassed.

## 2. Cerberus completion

**LOCKED**

After Cerberus is defeated:
- finish the final required resolution work
- do not reveal a normal Reward
- transition directly into the final Divinity / Ascension sequence

## 3. Hercules' Ascension

**LOCKED DIRECTION**

Use the verified `HERCULES' ASCENSION` artwork as the thematic final image.

Preferred presentation:
- Cerberus/full-Labor scene gives way to the Ascension sequence
- view/camera pans upward
- Ascension artwork enters from above / becomes the primary visual
- upward motion reinforces ascent rather than using a generic confetti/reward treatment

## 4. Final Divinity requirement

**LOCKED PRINCIPLE**

The engine owns the final Divinity requirement/check.

Presentation must make the final result legible before declaring victory.

If the final Divinity requirement fails, branch to the Game Defeat flow rather than displaying Victory.

## 5. Victory title

**LOCKED DIRECTION**

After successful final requirement:
- show `VICTORY`
- keep typography restrained and low enough not to obscure the Ascension art
- avoid excessive celebratory overlays

The Ascension artwork remains the primary visual payoff.

## 6. Reward exception

**LOCKED**

No normal Cerberus Reward selection/acquisition occurs.

The endgame payoff is Ascension/Victory.

## 7. Stats / run summary

**LOCKED DIRECTION**

Do not automatically cover the victory image with statistics during the initial victory beat.

A later optional summary/review screen may exist, but it should follow the primary Ascension moment.

## 8. Controls

**PROVISIONAL**

Post-victory controls may later include:
- Review Run
- New Game
- Main Menu

Exact timing and navigation remain product/implementation decisions.

## 9. UI / Engine boundary

### Engine owns
- Cerberus defeat
- final Divinity requirement
- victory/defeat result
- canonical final state

### UI owns
- Ascension transition
- upward camera movement
- art presentation
- Victory typography
- post-victory navigation

## Recovered locked summary

- Cerberus bypasses Reward flow
- final Divinity requirement resolves before victory declaration
- use `HERCULES' ASCENSION` art
- pan/move upward into Ascension
- restrained `VICTORY` near bottom
- no automatic stats overlay during the core victory beat
