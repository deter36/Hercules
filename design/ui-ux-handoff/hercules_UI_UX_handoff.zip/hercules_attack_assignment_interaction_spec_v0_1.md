# Hercules Digital Adaptation — Attack Assignment Interaction Spec v0.1

**Status:** Working UI authority  
**Scope:** Hercules-die selection, target highlighting, attack-group construction, assignment, rejection behavior, CTA behavior, and forecast interaction on the main gameplay screen.

This specification governs presentation and input only. The engine remains authoritative for dice state, legal placements, attack requirements, allocations, and phase progression.

## 1. Core interaction principle

**Status: LOCKED**

For attacks requiring more than one die:

> **Select the dice for one attack. Drag them to the Labor. Repeat.**

One selection represents **one proposed attack group**.

The interface does not automatically partition a larger selection into multiple legal attacks.

Example for a requirement of total exactly 18:

- `6,6,6` may be selected and assigned as one attack.
- `6,4,3,5` may then be selected and assigned as a second attack.
- Selecting all seven dice together does **not** automatically create those two attacks.

The engine validates the submitted selected group as one proposed allocation. This preserves the player's responsibility for attack grouping.

## 2. Dice selection

**Status: LOCKED**

Dice are added to or removed from the current selection individually by tapping them.

- tap unselected die → add to selection
- tap selected die → remove from selection
- dragging any selected die drags the entire selected group
- tapping empty tray/background does **not** clear the selection

There is only one active loose-dice selection at a time.

## 3. Tray visual states

**Status: LOCKED**

The tray does **not** communicate whether the selected combination is legal.

Necessary states are:
- normal
- selected
- dragging
- unavailable/broken/spent as required by canonical state

There is no `candidate-valid` or `candidate-invalid` visual treatment in the tray.

## 4. Legality feedback belongs in the action surface

**Status: LOCKED**

The currently selected dice cause **legal placement targets** to highlight.

The selected dice themselves do not change appearance when the selection becomes legal.

If no legal target exists for the current selection, no target highlights.

## 5. Legal-target highlighting is global

**Status: LOCKED**

Target highlighting is not Labor-specific.

Depending on canonical state and phase, legal targets may include:
- Blue ability squares
- Gold ability squares
- Labor target panes
- verified temporary/actionable effect tiles

The engine supplies legal target information. The UI only renders those returned targets as available.

## 6. Contextual CTA while dice are selected

**Status: LOCKED**

Once at least one die is selected, the normal phase CTA is temporarily replaced by an **Unselect** action.

Tapping Unselect:
- clears the current dice selection
- leaves canonical placements unchanged
- returns the CTA to its phase-appropriate action

The exact icon/text treatment is provisional.

## 7. One selection = one attack

**Status: LOCKED**

For a Labor attack requiring multiple dice, the full selected set must satisfy **one instance** of that attack requirement.

The engine does not search for multiple valid partitions.

### Cerberus example

Suppose the player selects:

`6,6,6,6,3,4,5`

Although this can be manually divided into:
- `6,6,6 = 18`
- `6,4,3,5 = 18`

the seven-die selection does not represent two attacks.

The player instead assigns those as two separate actions.

## 8. Invalid attack drop

**Status: LOCKED**

An invalid selected attack group does **not** remain on the Labor tile.

If dropped onto an illegal target:
1. placement is rejected
2. dice animate back to the tray
3. the current selection remains active
4. player can immediately add/remove dice and try again

## 9. Snapback destination

**Status: PROVISIONAL**

Preferred behavior: return dice to their original tray slots.

Implementation fallback: return them to the first available tray positions in stable physical-die order.

Avoid arbitrary reshuffling or nondeterministic return positions.

## 10. Selection after invalid drop

**Status: LOCKED**

The dice remain selected after snapping back.

The player can then tap dice to remove them until the selected group forms the desired attack.

## 11. Valid attack drop

**Status: LOCKED**

If the selected group satisfies one legal attack for the chosen Labor target:
1. the engine accepts the allocation
2. the dice move into the target pane
3. they become one visually grouped attack bundle
4. the loose selection clears
5. the phase CTA returns
6. Forecast updates immediately

Nothing resolves yet.

## 12. Assigned attack bundle

**Status: LOCKED**

A successfully assigned attack is visually represented as a discrete bundle.

Permanent labels such as `Attack 1` are not currently required.

Bundle boundaries must remain visually clear when multiple attacks are assigned to the same Labor target.

## 13. Multiple attacks on the same Labor target

**Status: LOCKED**

Each valid assignment creates a separate attack bundle.

The UI does not merge multiple separately assigned attacks into one larger allocation.

## 14. Editing an assigned attack

**Status: LOCKED PRINCIPLE**

Assignments remain reversible before resolution.

The player must be able to:
- remove an assigned bundle
- return it to the tray
- move it to another legal Labor target where applicable

Preferred interaction:
- tap completed bundle → bundle selected
- drag bundle → move entire attack allocation

Exact visual treatment remains provisional.

## 15. Forecast behavior

**Status: LOCKED**

Forecast reflects **valid committed assignments only**.

- building a selection in tray → no forecast change
- valid selected group not yet placed → no forecast change
- valid group placed on Labor → forecast updates immediately
- invalid group attempted → forecast remains unchanged

## 16. Resolve Assignments CTA

**Status: LOCKED**

Because illegal attack groups cannot remain assigned to Labor tiles, an invalid Labor bundle does not need to block Resolve Assignments.

Instead:
- loose selected dice → CTA is temporarily `Unselect`
- valid committed assignments → normal Resolve CTA
- illegal drop → rejected before becoming assignment state

The engine's separate unused-meaningful-placement rule remains separate.

## 17. Single-die attacks

**Status: PROVISIONAL / TEST REQUIRED**

Initial implementation preserves the conceptual rule: one selection = one attack.

Possible future optimization:
- select several independently legal singleton attacks
- drag once
- engine treats them as separate one-die bundles

Add only if usability testing shows the repetitive baseline is materially cumbersome.

## 18. Multi-bundle bulk movement

**Status: DEFERRED**

Selecting several already-completed attack bundles and moving them simultaneously is technically possible, but not necessary for the initial interaction model.

There is currently no bulk construction of several attacks from loose dice.

## 19. Tutorial rule

**Status: LOCKED CONCEPT**

> **Select the dice for one attack, then drag them to the Labor.**

Additional helper feedback can teach:
- selected dice move together
- highlighted targets accept the current selection
- rejected groups return to the tray
- repeat to assign another attack

## 20. UI / Engine responsibilities

**Status: LOCKED — NON-NEGOTIABLE**

### Engine
Responsible for:
- current Hercules-die state
- current selection eligibility
- legal targets
- attack requirement validation
- legal allocation validation
- Labor target eligibility
- committed attack allocations
- Forecast result
- placement rejection
- phase legality

### UI
Responsible for:
- showing selected dice
- visually moving the selected group
- highlighting engine-returned legal targets
- submitting the selected group + chosen target
- animating accepted placement
- animating rejection/snapback
- visually grouping committed attack bundles
- rendering Forecast returned by the engine

The UI must not independently partition dice, validate attack equations, or determine attack legality.

## Locked / Provisional / Deferred Summary

### Locked
- tap dice individually to build selection
- tapping background does not clear selection
- selected dice have no tray-side legal/illegal state
- legal feedback appears through target highlighting
- highlighting applies across the whole gameplay action surface
- CTA becomes Unselect while loose dice are selected
- one selection represents one proposed attack
- no automatic partitioning into multiple attacks
- multi-die attacks are assigned one legal bundle at a time
- invalid Labor drop snaps back
- selection survives snapback
- only valid attack bundles can occupy Labor panes
- each valid attack creates a distinct visual bundle
- Forecast changes only after valid assignment
- attack placement never resolves automatically

### Provisional
- original-slot vs first-available-slot snapback
- exact bundle graphic treatment
- bundle selection/movement visuals
- singleton bulk-assignment optimization
- exact Unselect CTA iconography

### Deferred
- moving multiple completed attack bundles simultaneously
- advanced bulk-placement shortcuts
